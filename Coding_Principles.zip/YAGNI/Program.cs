﻿// See https://aka.ms/new-console-template for more information
using System.Text.Json;

Console.WriteLine("Hello, World!");
/*
 * Avoid unnecessary functionalities
 * Do not try to solve problems or implement solutions
 * that do not exist, just because you think you will need it...
 * you are not gonna need it...
 */

public class YAGNI
{
    //🤕
    public string JSONResult()
    {
        return JsonSerializer.Serialize(this);
    }

    public string XMLResult()
    {
        throw new NotImplementedException();
    }

    public string AnyOtherResult()
    {
        throw new NotImplementedException();
    }
}