﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

/*CODING PRINCIPLES*/

//Good programmers write the code that humans can understand
//Any fool can write the code that computer can understand
/*Easy to understand and maintain,extend and change by any developer 
   what and why ??

your code must express what exactly it does...
human readable names
self explanatory names..
write methods to do one thing..

1. KISS - KEEP IT SIMPLE STUPID...1960s..
   simplicity is the ultimate sophistication..
   make your code simple
   avoid unnecessary complexity
   if its easier to read, then its easier to maintain
   no hard rules to say which is simple or complex
   simplicity is in the eye of beholder..

2. DRY
   Dont repeat yourself..

3. YAGNI

4. SOLID

5. FAVOR COMPOSITION OVER INHERITENCE

6. SEPARATION OF CONCERNS


--> A method should not have more than 50 lines of code
    the smaller the method - you can easily write the unit test.
--> A method should not take more than 3-4 parameters
    create a model/class and take it as input
--> 


 */

var obj = new KISS();
Console.WriteLine(obj.GetMonth(4));

public class KISS
{
    public string GetMonth(int month)
    {
        switch (month)
        {
            case 1:
                return "January";
            case 2:
                return "February";
            case 3:
                return "March";
            case 4:
                return "April";
            default:
                throw new InvalidOperationException("Ohh common month has to be between 1 and 12");
        }
    }
}