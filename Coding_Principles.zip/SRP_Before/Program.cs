﻿/*
 UNCLE BOB - 2000 
 PAPER DESIGN PRINCIPLES AND DESIGN PATTERNS

 SOLID
 S --> SINGLE RESPONSIBILITY PRINCIPLE
  
 Every class or module 
 - has single responsibility 
 - or specific functionality
 
 If your class has many responsibilities
 - may be it is high time to split them into smaller ones..

 Ask yourself - what is the responsibility of the class ??

 if there is 'AND' 🤷‍
 Then break it...😊
 */

public class Rectangle
{
    public double Area(int l,int b) => l * b;

    public double Perimeter(int l,int b) => 2*(l+b);

  

}

public class Circle
{
    public double CalculateCircleArea1(int r) => 3.14 * r * r;
}