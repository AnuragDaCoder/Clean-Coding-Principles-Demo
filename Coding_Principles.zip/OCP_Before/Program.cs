﻿using static System.Console;

namespace DotNetDesignPatternDemos.SOLID.OCP
{
    public enum DressType
    {
        Shirt, Pant ,Sundress , Culotte_dress
    }

    public enum Price
    {
        Low, Average, Costly
    }

    public enum Brand
    {
        Lee_Cooper, Indigo_Nation, Van_Heusen, Louis_Philippe, Louis_Vuitton, Gucci
    }

    public class Dress
    {
        public DressType DressType;
        public Brand Brand;
        public Price Price;

        public Dress(DressType dressType, Brand brand, Price price)
        {
            DressType = dressType;
            Brand = brand;
            Price = price;
        }
    }

    public class DressFilter
    {
        public IEnumerable<Dress> FilterByBrand(IEnumerable<Dress> dresses, Brand brand)
        {
            
            //
            WriteLine( "--------------Filtering by brand---------------");
            foreach (var dress in dresses)
                if (dress.Brand == brand)
                    yield return dress;
        }

        public IEnumerable<Dress> FilterByPrice(IEnumerable<Dress> dresses, Price price)
        {
            WriteLine("--------------Filtering by Price---------------");
            foreach (var dress in dresses)
                if (dress.Price == price)
                    yield return dress;
        }

        public static IEnumerable<Dress> FilterByBrandAndPrice(IEnumerable<Dress> dresses, Brand brand, Price price)
        {
            foreach (var dress in dresses)
                if (dress.Price == price && dress.Brand == brand)
                    yield return dress;
        }
    }


    public class Demo
    {
        static void Main(string[] args)
        {
            var dressList = new List<Dress>()
            {
                new Dress(DressType.Shirt,Brand.Lee_Cooper,Price.Low),
                new Dress(DressType.Pant,Brand.Van_Heusen,Price.Costly),
                new Dress(DressType.Shirt,Brand.Lee_Cooper,Price.Costly),
                new Dress(DressType.Shirt,Brand.Lee_Cooper,Price.Average),
                new Dress(DressType.Shirt,Brand.Van_Heusen,Price.Costly),
                new Dress(DressType.Sundress,Brand.Louis_Vuitton,Price.Costly),
                new Dress(DressType.Culotte_dress,Brand.Gucci,Price.Costly),
            };

            var dressFilter = new DressFilter();

            var vanHeusenDress = dressList.Where(x => x.Brand.Equals(Brand.Van_Heusen));

            //foreach (var dress in dressFilter.FilterByBrand(dressList, Brand.Van_Heusen))
            //    WriteLine($" Dress Type is- {dress.DressType} --> Brand is {dress.Brand}");

            foreach (var dress in dressFilter.FilterByPrice(dressList, Price.Costly))
                WriteLine($" Dress Type is- {dress.DressType} --> Brand is {dress.Brand} --> Price is :{dress.Price}");

        }
    }
}
