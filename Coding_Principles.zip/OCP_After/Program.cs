﻿using System.Drawing;
using static System.Console;

namespace DotNetDesignPatternDemos.SOLID.OCP
{
    public enum DressType
    {
        Shirt, Pant, Sundress, Culotte_dress
    }

    public enum Price
    {
        Low, Average, Costly
    }

    public enum Brand
    {
        Lee_Cooper, Indigo_Nation, Van_Heusen, Louis_Philippe, Louis_Vuitton, Gucci
    }
    public enum Color
    {
        Red,Blue, Green, Blue_Gold, Green_Red, Green_Green
    }
    public class Dress
    {
        public DressType DressType;
        public Brand Brand;
        public Price Price;
        public Color Color;

        public Dress(DressType dressType, Brand brand, Price price,Color color)
        {
            DressType = dressType;
            Brand = brand;
            Price = price;
            Color = color;
        }
    }


    public interface IFilterBy
    {
        bool IsSatisfied(Dress dress);
    }

    public class BrandFilter : IFilterBy
    {
        private Brand _brand;
        public BrandFilter(Brand brand)
        {
            _brand = brand;
        }

        public bool IsSatisfied(Dress dress)
        {
            return _brand == dress.Brand;
        }
    }

    public class PriceFilter : IFilterBy
    {
        private Price _price;
        public PriceFilter(Price price)
        {
            _price = price;
        }

        public bool IsSatisfied(Dress dress)
        {
            return _price == dress.Price;
        }
    }

    public class ColorFilter : IFilterBy
    {
        private Color _color;
        public ColorFilter(Color color)
        {
            _color = color;
        }
        public bool IsSatisfied(Dress dress)
        {
            return _color == dress.Color;
        }
    }

    public class PriceAndBrandFilter : IFilterBy
    {
        private Price _price;
        private Brand _brand;
        public PriceAndBrandFilter(Price price,Brand brand)
        {
            _price = price;
            _brand = brand;
        }

        public bool IsSatisfied(Dress dress)
        {
            return _price == dress.Price && _brand==dress.Brand;
        }
    }

    public interface ISuperDressFilter
    {
        IEnumerable<Dress> Filter(IEnumerable<Dress> dresses, IFilterBy filterBy);
    }

    public class SuperDressFilter: ISuperDressFilter
    {
        //IFilterBy filterBy = new PriceFilter();
        public IEnumerable<Dress> Filter(IEnumerable<Dress> dresses, IFilterBy filterBy)
        {
            WriteLine("--------------Filtering by everything---------------");
            foreach (var dress in dresses)
                if (filterBy.IsSatisfied(dress))
                    yield return dress;
        }
    }


    public class DressFilter
    {
        public IEnumerable<Dress> FilterByBrand(IEnumerable<Dress> dresses, Brand brand)
        {

            //
            WriteLine("--------------Filtering by brand---------------");
            foreach (var dress in dresses)
                if (dress.Brand == brand)
                    yield return dress;
        }

        public IEnumerable<Dress> FilterByPrice(IEnumerable<Dress> dresses, Price price)
        {
            WriteLine("--------------Filtering by Price---------------");
            foreach (var dress in dresses)
                if (dress.Price == price)
                    yield return dress;
        }

        public static IEnumerable<Dress> FilterByBrandAndPrice(IEnumerable<Dress> dresses, Brand brand, Price price)
        {
            foreach (var dress in dresses)
                if (dress.Price == price && dress.Brand == brand)
                    yield return dress;
        }
    }


    public class Demo
    {
        static void Main(string[] args)
        {
            var dressList = new List<Dress>()
            {
                new Dress(DressType.Shirt,Brand.Lee_Cooper,Price.Low,Color.Green),
                new Dress(DressType.Pant,Brand.Van_Heusen,Price.Costly,Color.Green),
                new Dress(DressType.Shirt,Brand.Lee_Cooper,Price.Costly,Color.Green),
                new Dress(DressType.Shirt,Brand.Lee_Cooper,Price.Average,Color.Green)
                //new Dress(DressType.Shirt,Brand.Van_Heusen,Price.Costly),
                //new Dress(DressType.Sundress,Brand.Louis_Vuitton,Price.Costly),
                //new Dress(DressType.Culotte_dress,Brand.Gucci,Price.Costly),
            };


            var dressFilter = new DressFilter();

            var vanHeusenDress = dressList.Where(x => x.Brand.Equals(Brand.Van_Heusen));

            //foreach (var dress in dressFilter.FilterByBrand(dressList, Brand.Van_Heusen))
            //    WriteLine($" Dress Type is- {dress.DressType} --> Brand is {dress.Brand}");

            foreach (var dress in dressFilter.FilterByPrice(dressList, Price.Costly))
                WriteLine($" Dress Type is- {dress.DressType} --> Brand is {dress.Brand} --> Price is :{dress.Price}");

            /****************************************************/

            var superFilter = new SuperDressFilter();
            foreach (var dress in superFilter.Filter(dressList,new BrandFilter(Brand.Louis_Vuitton)))
                WriteLine($" Dress Type is- {dress.DressType} --> Brand is {dress.Brand} --> Price is :{dress.Price}");

         
            foreach (var dress in superFilter.Filter(dressList, new PriceFilter(Price.Average)))
                WriteLine($" Dress Type is- {dress.DressType} --> Brand is {dress.Brand} --> Price is :{dress.Price}");

            foreach (var dress in superFilter.Filter(dressList, new PriceAndBrandFilter(Price.Average,Brand.Lee_Cooper)))
                WriteLine($" Dress Type is- {dress.DressType} --> Brand is {dress.Brand} --> Price is :{dress.Price}");

            foreach (var dress in superFilter.Filter(dressList, new ColorFilter(Color.Green)))
                WriteLine($" Dress Type is- {dress.DressType} --> Brand is {dress.Brand} --> Price is :{dress.Price} --dress color--> {dress.Color}");


        }
    }
}
